package io.github.workto0725.hankkiplus;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
