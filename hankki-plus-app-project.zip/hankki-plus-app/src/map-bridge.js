export function installMapBridge() {
  const origin='https://workto0725.github.io', channel='hankki-native-map-v1';
  const frame=document.createElement('iframe');frame.src=origin+'/good-price-food/native-map.html';frame.title='한끼 지도';frame.style.cssText='width:100%;height:100%;border:0;display:block';frame.referrerPolicy='no-referrer';document.querySelector('#mapEl').appendChild(frame);
  let counter=0,resolveReady,rejectReady,currentMap;
  const pending=new Map(), overlays=new Map();
  const ready=new Promise((resolve,reject)=>{resolveReady=resolve;rejectReady=reject});ready.catch(()=>{});
  const timer=setTimeout(()=>rejectReady(new Error('지도 연결에 실패했어요. 인터넷 연결을 확인해주세요.')),18000);
  const post=message=>frame.contentWindow.postMessage({channel,...message},origin);
  frame.addEventListener('load',()=>post({type:'hello'}));
  window.addEventListener('message',event=>{
    if(event.origin!==origin||event.source!==frame.contentWindow||event.data?.channel!==channel)return;
    const m=event.data;
    if(m.type==='ready'){clearTimeout(timer);resolveReady()}
    if(m.type==='failed'){clearTimeout(timer);rejectReady(new Error(m.error))}
    if(m.type==='result'){const p=pending.get(m.id);if(!p)return;clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(new Error(m.error)):p.resolve(m.result)}
    if(m.type==='pin-click')overlays.get(m.id)?.content.click();
    if(m.type==='map-click')currentMap?.click?.();
  });
  async function rpc(action,data){await ready;return new Promise((resolve,reject)=>{const id=String(++counter),timer=setTimeout(()=>{pending.delete(id);reject(new Error('지도 요청 시간이 초과됐어요.'))},12000);pending.set(id,{resolve,reject,timer});post({type:'request',id,action,data})})}
  const command=(action,data)=>rpc(action,data).catch(error=>window.dispatchEvent(new CustomEvent('hankki:native-error',{detail:error.message})));
  class LatLng{constructor(lat,lng){this.lat=Number(lat);this.lng=Number(lng)}}
  class LatLngBounds{constructor(){this.points=[]}extend(point){this.points.push(point)}}
  class MapView{
    constructor(element,options){currentMap=this;command('map-init',options)}
    relayout(){command('map-relayout')}setCenter(point){command('map-center',point)}panTo(point){command('map-pan',point)}setLevel(level){command('map-level',level)}setBounds(bounds){command('map-bounds',bounds.points)}
  }
  class CustomOverlay{
    constructor(options){this.options=options;this.content=options.content;this.id='pin-'+(++counter)}
    setMap(map){if(!map){overlays.delete(this.id);command('pin-remove',{id:this.id});return}overlays.set(this.id,this);command('pin-add',{id:this.id,position:this.options.position,yAnchor:this.options.yAnchor,html:this.content.outerHTML})}
  }
  const Status={OK:'OK',ZERO_RESULT:'ZERO_RESULT',ERROR:'ERROR'};
  class Places{
    keywordSearch(query,callback,options={}){this.search('keyword',query,callback,options)}
    categorySearch(query,callback,options={}){this.search('category',query,callback,options)}
    search(kind,query,callback,options){rpc('search',{kind,query,options}).then(r=>callback(r.rows,r.status,{hasNextPage:r.more}),()=>callback([],Status.ERROR))}
  }
  class Geocoder{addressSearch(query,callback){rpc('address',{query}).then(r=>callback(r.rows,r.status),()=>callback([],Status.ERROR))}}
  window.kakao={maps:{LatLng,LatLngBounds,Map:MapView,CustomOverlay,services:{Places,Geocoder,Status,SortBy:{DISTANCE:'distance'}},event:{addListener(map,type,callback){if(type==='click')map.click=callback}}}};
}
