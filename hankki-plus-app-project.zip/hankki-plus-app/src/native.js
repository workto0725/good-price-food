import { Capacitor } from '@capacitor/core';
import { App } from '@capacitor/app';
import { Geolocation } from '@capacitor/geolocation';
import { Camera, CameraSource, CameraResultType } from '@capacitor/camera';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { installMapBridge } from './map-bridge.js';

const native = Capacitor.isNativePlatform();
const DATA = 'hankki-records.json';
let writes = Promise.resolve();
const owned = key => String(key).startsWith('hankki_');
const report = error => {
  console.error('Native operation failed', error);
  window.dispatchEvent(new CustomEvent('hankki:native-error', { detail: '기기 작업을 완료하지 못했어요. 권한과 저장 공간을 확인해주세요.' }));
};
function snapshot() {
  return Object.fromEntries(Object.keys(localStorage).filter(owned).map(key => [key, localStorage.getItem(key)]));
}
async function loadRecords() {
  for (const path of [DATA + '.backup', DATA]) {
    try {
      const result = await Filesystem.readFile({ path, directory: Directory.Data, encoding: Encoding.UTF8 });
      const values = JSON.parse(result.data);
      if (!values || typeof values !== 'object' || Array.isArray(values)) throw new Error('Invalid local records');
      for (const [key, value] of Object.entries(values)) if (owned(key) && typeof value === 'string') localStorage.setItem(key, value);
      return;
    } catch (error) {
      // A fresh install has no native file. Existing WebView records remain intact.
      if (path === DATA) console.info('Local native restore unavailable; using WebView records.');
    }
  }
}
function installStorage() {
  const set = Storage.prototype.setItem, remove = Storage.prototype.removeItem;
  function save() {
    const data = JSON.stringify(snapshot());
    writes = writes.catch(() => {}).then(async () => {
      await Filesystem.writeFile({ path: DATA + '.backup', directory: Directory.Data, encoding: Encoding.UTF8, data });
      await Filesystem.writeFile({ path: DATA, directory: Directory.Data, encoding: Encoding.UTF8, data });
    }).catch(report);
  }
  Storage.prototype.setItem = function(key, value) {
    set.call(this, key, value);
    if (this === localStorage && owned(key)) save();
  };
  Storage.prototype.removeItem = function(key) {
    remove.call(this, key);
    if (this === localStorage && owned(key)) save();
  };
  return save;
}
async function saveAndShare(blob, name) {
  const base64 = await new Promise((resolve, reject) => {
    const reader = new FileReader(); reader.onerror = reject;
    reader.onload = () => resolve(String(reader.result).split(',')[1]); reader.readAsDataURL(blob);
  });
  const file = await Filesystem.writeFile({ path: name.replace(/[\\/]/g, '_'), directory: Directory.Cache, data: base64 });
  await Share.share({ title: '한끼일기+', files: [file.uri], dialogTitle: '저장하거나 공유할 앱을 선택하세요' });
}
const bridge = window.HankkiNative = {
  native,
  ready: Promise.resolve(),
  async position() {
    let permission = await Geolocation.checkPermissions();
    if (permission.location === 'prompt' || permission.location === 'prompt-with-rationale') permission = await Geolocation.requestPermissions();
    if (permission.location === 'denied' && permission.coarseLocation !== 'granted') throw new Error('위치 권한을 허용해주세요. 이름 검색은 위치 없이도 사용할 수 있어요.');
    return Geolocation.getCurrentPosition({ enableHighAccuracy: permission.location === 'granted', timeout: 10000, maximumAge: 60000 });
  },
  async photo(source) {
    try {
      const photo = await Camera.getPhoto({ source: source === 'camera' ? CameraSource.Camera : CameraSource.Photos, resultType: CameraResultType.Uri, quality: 85, width: 1600, correctOrientation: true, saveToGallery: false });
      if (!photo.webPath) throw new Error('사진을 불러오지 못했어요.');
      const blob = await (await fetch(photo.webPath)).blob();
      window.dispatchEvent(new CustomEvent('hankki:native-photo', { detail: [new File([blob], 'meal.' + photo.format, { type: blob.type || 'image/jpeg' })] }));
    } catch (error) {
      if (!/cancel|취소|User cancelled/i.test(String(error?.message))) report(error);
    }
  },
  shareBlob: saveAndShare,
  flush: () => writes
};
if (native) {
  installMapBridge();
  bridge.ready = loadRecords().then(async () => {
    const save = installStorage(); save();
    document.addEventListener('click', event => {
      const label = event.target.closest('label[for="fCam"],label[for="fAlbum"]');
      if (!label) return;
      event.preventDefault(); event.stopImmediatePropagation();
      bridge.photo(label.htmlFor === 'fCam' ? 'camera' : 'photos');
    }, true);
    await App.addListener('backButton', () => {
      if (document.querySelector('#ob.open')) { document.querySelector('[data-act="ob-skip"]')?.click(); return; }
      if (document.querySelector('#dlg.open')) { document.querySelector('#dlg button')?.click(); return; }
      if (document.querySelector('.sheet.open')) { history.back(); return; }
      if (!document.querySelector('#v-home.active')) { document.querySelector('[data-tab="home"]')?.click(); return; }
      App.minimizeApp();
    });
    await App.addListener('appStateChange', ({ isActive }) => { if (!isActive) save(); });
  }).catch(report);
}
