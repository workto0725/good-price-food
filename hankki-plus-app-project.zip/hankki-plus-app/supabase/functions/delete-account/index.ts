import { createClient } from 'npm:@supabase/supabase-js@2.49.1';

const headers = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Content-Type': 'application/json' };
const reply = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers });
Deno.serve(async request => {
  if (request.method === 'OPTIONS') return new Response(null, { headers });
  if (request.method !== 'POST') return reply(405, { error: 'METHOD_NOT_ALLOWED' });
  const authorization = request.headers.get('authorization');
  if (!authorization?.startsWith('Bearer ')) return reply(401, { error: 'AUTH_REQUIRED' });
  const url = Deno.env.get('SUPABASE_URL');
  const key = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !key) return reply(503, { error: 'SERVER_NOT_CONFIGURED' });
  const admin = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data, error } = await admin.auth.getUser(authorization.slice(7));
  if (error || !data.user) return reply(401, { error: 'AUTH_REQUIRED' });
  let body;
  try { body = await request.json(); } catch { return reply(400, { error: 'INVALID_REQUEST' }); }
  if (body.confirm !== 'DELETE_MY_ACCOUNT') return reply(400, { error: 'CONFIRM_REQUIRED' });
  // Never accept a client-provided user id. FK cascades remove this account's posts,
  // saves, reports and moderation membership, as defined in community setup SQL.
  const result = await admin.auth.admin.deleteUser(data.user.id, false);
  if (result.error) return reply(500, { error: 'DELETE_FAILED' });
  return reply(200, { deleted: true });
});
