import fs from 'node:fs/promises';
let html=await fs.readFile('src/index.html','utf8');
if(!html.includes('function appAccountDelete')){
  html=html.replace("function comPost(x){", "function comPost(x){if(['public','saved'].indexOf(COM.mode)>=0&&getJSON('hankki_hidden_authors_v1',[]).indexOf(x.author_id)>=0)return ''; ");
  html=html.replace("data-act=\"com-report\" data-id=\"'+esc(x.id)+'\">신고</button>", "data-act=\"com-report\" data-id=\"'+esc(x.id)+'\">신고</button>'+(!own?'<button class=\"setbtn\" data-act=\"app-userblock\" data-author=\"'+esc(x.author_id)+'\">사용자 차단</button>':'')+'");
  html=html.replace('data-act="com-logout">로그아웃</button>', 'data-act="com-logout">로그아웃</button><button class="setbtn" data-act="app-delete-account">회원 탈퇴</button>');
  html=html.replace("html+='<p class=\"note\" style=\"text-align:center", "html+='<h2 class=\"sec\">이용 안내</h2><div class=\"card\"><p><a href=\"privacy.html\" target=\"_blank\" rel=\"noopener\">개인정보처리방침</a> · <a href=\"terms.html\" target=\"_blank\" rel=\"noopener\">이용약관</a></p><button class=\"setbtn\" data-act=\"app-unblock\">차단한 사용자 모두 해제</button></div>';\n  html+='<p class=\"note\" style=\"text-align:center");
  const code=`
async function appAccountDelete(){
 if(!COM.user){comAuth();return}
 var yes=await ask({title:'회원 탈퇴',text:'커뮤니티 계정과 작성한 추천 글·저장·신고 내역을 삭제합니다. 이 기기의 개인 한끼 기록은 유지됩니다. 삭제 후 복구할 수 없습니다.',ok:'탈퇴하기',cancel:'취소',danger:true});if(!yes)return;
 try{var c=await comReady(),result=await c.functions.invoke('delete-account',{body:{confirm:'DELETE_MY_ACCOUNT'}});if(result.error||!result.data||!result.data.deleted)throw new Error('DELETE_FAILED');await c.auth.signOut();COM.user=null;COM.admin=false;COM.mode='public';COM.rows=[];COM.epoch++;toast('계정과 커뮤니티 데이터를 삭제했어요.');comLoad(false)}catch(e){toast('탈퇴를 완료하지 못했어요. 잠시 후 다시 시도해주세요.',{error:true})}
}
document.addEventListener('click',async function(e){var b=e.target.closest('[data-act^="app-"]');if(!b)return;
 if(b.dataset.act==='app-delete-account'){appAccountDelete();return}
 if(b.dataset.act==='app-userblock'){if(!await ask({title:'사용자 차단',text:'이 기기에서 이 작성자의 추천 글을 숨깁니다. 설정에서 차단을 해제할 수 있어요.',ok:'차단',cancel:'취소'}))return;var hidden=getJSON('hankki_hidden_authors_v1',[]);if(hidden.indexOf(b.dataset.author)<0)hidden.push(b.dataset.author);if(setJSON('hankki_hidden_authors_v1',hidden)){renderShareHub();toast('사용자를 차단했어요.')}}
 if(b.dataset.act==='app-unblock'){if(await ask({title:'차단 해제',text:'차단한 모든 작성자의 추천 글을 다시 표시할까요?',ok:'해제',cancel:'취소'})){setJSON('hankki_hidden_authors_v1',[]);renderShareHub();toast('차단을 해제했어요.')}}
});
`;
  html=html.replace('var COM={',code+'\nvar COM={');
  await fs.writeFile('src/index.html',html);
}
