import json, plistlib, re
from pathlib import Path
root=Path(__file__).resolve().parent.parent
p=root/'ios/App/App/Info.plist'
info=plistlib.loads(p.read_bytes())
info.update({
 'NSCameraUsageDescription':'먹은 음식 사진을 촬영해 개인 한끼 기록에 첨부합니다.',
 'NSPhotoLibraryUsageDescription':'선택한 음식 사진을 개인 한끼 기록에 첨부합니다.',
 'NSPhotoLibraryAddUsageDescription':'원할 때 한끼 추천 카드를 사진 앨범에 저장합니다.',
 'NSLocationWhenInUseUsageDescription':'주변 식당을 거리순으로 찾고 지도에 현재 위치를 표시합니다.',
 'NSLocationAlwaysAndWhenInUseUsageDescription':'앱 사용 중 주변 식당 검색에만 위치를 사용하며 백그라운드 위치는 수집하지 않습니다.'
})
p.write_bytes(plistlib.dumps(info))
manifest={'NSPrivacyTracking':False,'NSPrivacyTrackingDomains':[], 'NSPrivacyCollectedDataTypes':[], 'NSPrivacyAccessedAPITypes':[{'NSPrivacyAccessedAPIType':'NSPrivacyAccessedAPICategoryFileTimestamp','NSPrivacyAccessedAPITypeReasons':['C617.1']}]}
(root/'ios/App/App/PrivacyInfo.xcprivacy').write_bytes(plistlib.dumps(manifest))
p=root/'ios/App/App.xcodeproj/project.pbxproj';s=p.read_text()
if 'PrivacyInfo.xcprivacy' not in s:
 s=s.replace('/* Begin PBXBuildFile section */','/* Begin PBXBuildFile section */\n\t\tAABB00112233445566778899 /* PrivacyInfo.xcprivacy in Resources */ = {isa = PBXBuildFile; fileRef = AABB00112233445566778898; };')
 s=s.replace('/* Begin PBXFileReference section */','/* Begin PBXFileReference section */\n\t\tAABB00112233445566778898 /* PrivacyInfo.xcprivacy */ = {isa = PBXFileReference; lastKnownFileType = text.xml; path = PrivacyInfo.xcprivacy; sourceTree = "<group>"; };')
 s=s.replace('504EC3131FED79650016851F /* Info.plist */,','504EC3131FED79650016851F /* Info.plist */,\n\t\t\t\tAABB00112233445566778898 /* PrivacyInfo.xcprivacy */,')
 s=s.replace('/* Begin PBXResourcesBuildPhase section */','/* Begin PBXResourcesBuildPhase section */',1)
 s=s.replace('504EC30F1FED79650016851F /* Assets.xcassets in Resources */,','504EC30F1FED79650016851F /* Assets.xcassets in Resources */,\n\t\t\t\tAABB00112233445566778899 /* PrivacyInfo.xcprivacy in Resources */,')
p.write_text(s)
p=root/'android/app/src/main/AndroidManifest.xml';s=p.read_text();s=s.replace('android:allowBackup="true"','android:allowBackup="false"')
if 'ACCESS_COARSE_LOCATION' not in s:s=s.replace('</manifest>','    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />\n    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />\n</manifest>')
p.write_text(s)
p=root/'package.json';pkg=json.loads(p.read_text());pkg['private']=True;pkg['description']='한끼일기+ Android/iOS native app project';pkg['scripts']['sync']='npm run build && npx cap sync && python3 scripts/configure-native.py';p.write_text(json.dumps(pkg,ensure_ascii=False,indent=2)+'\n')
print('Configured foreground location, camera, privacy manifest and Android backup policy.')
