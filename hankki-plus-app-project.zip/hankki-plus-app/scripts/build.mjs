import fs from 'node:fs/promises';
import { build } from 'esbuild';
await fs.mkdir('www', { recursive: true });
await build({ entryPoints: ['src/native.js'], outfile: 'www/native.js', bundle: true, format: 'iife', target: ['es2020'], minify: true });
let html = await fs.readFile('src/index.html', 'utf8');
html = html.replace('(function loadKakao(){', '(function loadKakao(){if(window.HankkiNative&&window.HankkiNative.native)return;');
html = html.replace('<script>\n', '<script src="native.js"></script>\n<script>\nwindow.HankkiNative.ready.then(function(){\n');
html = html.replace('</script>\n</body>', '});\n</script>\n</body>');
html = html.replace('function getPosition(){', 'function getPosition(){\n  if(window.HankkiNative.native)return window.HankkiNative.position().then(function(p){var pos={lat:p.coords.latitude,lng:p.coords.longitude};S.pos=pos;return pos});');
html = html.replace('function exportData(){', `function exportData(){
  if(window.HankkiNative.native){window.HankkiNative.shareBlob(new Blob([localStorage.getItem(K.meals)||'[]'],{type:'application/json'}),'한끼일기+_기록백업_'+dayKey(new Date())+'.json').catch(function(){toast('백업 공유를 완료하지 못했어요.',{error:true})});return}`);
html = html.replace('function downloadShareCard(){', `function downloadShareCard(){
  if(window.HankkiNative.native){if(shareCardState.blob)window.HankkiNative.shareBlob(shareCardState.blob,'한끼일기+_추천카드.png').catch(function(){toast('이미지 공유를 완료하지 못했어요.',{error:true})});return}`);
html = html.replace('function sendShareCard(){', `function sendShareCard(){
  if(window.HankkiNative.native){downloadShareCard();return}`);
html = html.replace("$('#fCam').addEventListener('change'", "window.addEventListener('hankki:native-photo',function(e){addPhotos(e.detail)});\nwindow.addEventListener('hankki:native-error',function(e){toast(e.detail,{error:true})});\n$('#fCam').addEventListener('change'");
html = html.replace('</head>', '<style>body{padding-top:env(safe-area-inset-top)}.phead{padding-top:calc(14px + env(safe-area-inset-top))}.pfoot{padding-bottom:calc(14px + env(safe-area-inset-bottom))}</style></head>');
await fs.writeFile('www/index.html', html);
await fs.copyFile('src/config.js', 'www/config.js');
for(const file of ['privacy.html','terms.html'])await fs.copyFile('src/'+file,'www/'+file);
console.log('Built bundled app with local meal UI and native device adapters.');
