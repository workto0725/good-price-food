from PIL import Image, ImageDraw
from pathlib import Path
import json
root=Path(__file__).resolve().parent.parent
(root/'store').mkdir(exist_ok=True)
size=1024
im=Image.new('RGB',(size,size),'#fff9f0');d=ImageDraw.Draw(im)
d.ellipse((200,260,824,884),fill='#835f47')
d.pieslice((228,288,796,856),180,360,fill='#edcaa1')
d.ellipse((334,345,690,701),fill='#fff9f0')
d.arc((367,120,477,290),-75,80,fill='#835f47',width=22)
d.arc((517,105,627,275),-75,80,fill='#835f47',width=22)
d.rounded_rectangle((733,174,861,294),radius=30,fill='#edcaa1')
d.line((797,198,797,270),fill='#835f47',width=14)
d.line((761,234,833,234),fill='#835f47',width=14)
im.save(root/'store/app-icon-1024.png')
im.resize((512,512),Image.Resampling.LANCZOS).save(root/'store/play-icon-512.png')
android=root/'android/app/src/main/res'
for folder,pixels in [('mipmap-mdpi',48),('mipmap-hdpi',72),('mipmap-xhdpi',96),('mipmap-xxhdpi',144),('mipmap-xxxhdpi',192)]:
 p=android/folder;p.mkdir(exist_ok=True)
 for name in ['ic_launcher.png','ic_launcher_round.png']:im.resize((pixels,pixels),Image.Resampling.LANCZOS).save(p/name)
 # Android adaptive icon foreground: keep artwork inside the safe circle.
 fg=Image.new('RGBA',(108*4,108*4),(0,0,0,0));art=im.resize((240,240),Image.Resampling.LANCZOS);fg.paste(art,(96,96));fg.resize((int(pixels*108/48),int(pixels*108/48)),Image.Resampling.LANCZOS).save(p/'ic_launcher_foreground.png')
p=android/'values/ic_launcher_background.xml';p.write_text('<?xml version="1.0" encoding="utf-8"?><resources><color name="ic_launcher_background">#fff9f0</color></resources>')
ios=root/'ios/App/App/Assets.xcassets/AppIcon.appiconset'
ios.mkdir(exist_ok=True);im.save(ios/'AppIcon-512@2x.png')
(ios/'Contents.json').write_text(json.dumps({'images':[{'filename':'AppIcon-512@2x.png','idiom':'universal','platform':'ios','size':'1024x1024'}],'info':{'author':'xcode','version':1}},indent=2))
print('Generated Android adaptive icons and opaque iOS 1024px app icon.')
