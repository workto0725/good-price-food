const assert=require('node:assert/strict'),fs=require('node:fs'),{JSDOM}=require('jsdom'),{build}=require('esbuild');
const tick=()=>new Promise(r=>setTimeout(r,40));
(async()=>{
 const html=fs.readFileSync('www/index.html','utf8');const dom=new JSDOM(html,{url:'https://localhost',runScripts:'outside-only'}),w=dom.window,d=w.document;
 const callbacks={},files=new Map();let geoCalls=0,permission='prompt';
 files.set('hankki-records.json.backup',JSON.stringify({hankki_diary_plus_onboard_v3:'1',hankki_meals_v1:'[]'}));
 const mocks=w.__nativeMocks={Capacitor:{isNativePlatform:()=>true},App:{addListener:async(name,fn)=>{callbacks[name]=fn},minimizeApp:()=>{}},Geolocation:{checkPermissions:async()=>({location:permission,coarseLocation:permission==='denied'?'denied':'granted'}),requestPermissions:async()=>({location:'granted'}),getCurrentPosition:async()=>{geoCalls++;return {coords:{latitude:35.267,longitude:129.233}}}},Camera:{getPhoto:async()=>{throw new Error('User cancelled')}},CameraSource:{Camera:'CAMERA',Photos:'PHOTOS'},CameraResultType:{Uri:'uri'},Directory:{Data:'DATA',Cache:'CACHE'},Encoding:{UTF8:'utf8'},Filesystem:{readFile:async({path})=>{if(!files.has(path))throw new Error('not found');return {data:files.get(path)}},writeFile:async({path,data})=>{files.set(path,data);return {uri:'file:///'+path}}},Share:{share:async()=>{}}};
 const out=await build({entryPoints:['src/native.js'],bundle:true,write:false,format:'iife',plugins:[{name:'native-test',setup(b){b.onResolve({filter:/^@capacitor\//},a=>({path:a.path,namespace:'mock'}));b.onLoad({filter:/.*/,namespace:'mock'},a=>({contents:({'@capacitor/core':['Capacitor'],'@capacitor/app':['App'],'@capacitor/geolocation':['Geolocation'],'@capacitor/camera':['Camera','CameraSource','CameraResultType'],'@capacitor/filesystem':['Filesystem','Directory','Encoding'],'@capacitor/share':['Share']}[a.path]).map(name=>'export const '+name+'=window.__nativeMocks.'+name+';').join('\n')}))}}]});
 w.eval(fs.readFileSync("src/config.js","utf8"));w.eval(out.outputFiles[0].text);await w.HankkiNative.ready;
 let inline=Array.from(d.querySelectorAll('script')).filter(s=>!s.src).map(s=>s.textContent).join('\n');w.eval(inline);await tick();
 const frame=d.querySelector('#mapEl iframe');const channel='hankki-native-map-v1';
 function reply(data){w.dispatchEvent(new w.MessageEvent('message',{origin:'https://workto0725.github.io',source:frame.contentWindow,data:{channel,...data}}))}
 frame.contentWindow.postMessage=m=>{if(m.type==='request'){reply({type:'result',id:m.id,result:m.action==='search'?{rows:[{id:'1',place_name:'일광 테스트식당',category_name:'음식점 > 중식',category_group_code:'FD6',road_address_name:'부산 기장군 일광읍',x:'129.233',y:'35.267',distance:'120'}],status:'OK',more:false}:true})}};
 reply({type:'ready'});
 assert.equal(d.querySelectorAll('.tabbar button').length,5);d.querySelector('.record-primary').click();d.querySelector('#fMenu').value='국밥';d.querySelector('#fMemo').value='작성 중인 기록';d.querySelector('[data-act="form-near"]').click();await tick();await tick();assert(d.querySelector('#plBody').textContent.includes('일광 테스트식당'));assert(geoCalls>0);assert(+w.getComputedStyle(d.querySelector('#sheetPick')).zIndex>+w.getComputedStyle(d.querySelector('#sheetForm')).zIndex);
 d.querySelector('#plBody .prow').click();await tick();assert.equal(d.querySelector('#fMenu').value,'국밥');assert.equal(d.querySelector('#fMemo').value,'작성 중인 기록');d.querySelector('#fSave').click();await tick();await w.HankkiNative.flush();assert.equal(JSON.parse(JSON.parse(files.get('hankki-records.json')).hankki_meals_v1)[0].menu,'국밥');
 permission='denied';await assert.rejects(w.HankkiNative.position(),/위치 권한/);await w.HankkiNative.photo('camera');
 w.localStorage.setItem('secret-session','not-in-backup');w.localStorage.setItem('hankki_hidden_authors_v1','["abc"]');await w.HankkiNative.flush();assert(!files.get('hankki-records.json').includes('not-in-backup'));assert(files.get('hankki-records.json').includes('hankki_hidden_authors_v1'));w.localStorage.removeItem('hankki_hidden_authors_v1');await w.HankkiNative.flush();assert(!files.get('hankki-records.json').includes('hankki_hidden_authors_v1'));
 // The map iframe stays mounted across tab changes, retaining SDK state.
 d.querySelector('[data-tab="map"]').click();await tick();assert.equal(d.querySelector('#mapEl iframe'),frame);callbacks.backButton();assert(d.querySelector('#v-home').classList.contains('active'));
 for(const s of d.querySelectorAll('script'))if(!s.src)new Function(s.textContent);
 for(const path of ['native-map.html','account-delete.html']){const page=new JSDOM(fs.readFileSync(path,'utf8'));for(const s of page.window.document.querySelectorAll('script'))if(!s.src)new Function(s.textContent);page.window.close()}
 assert(fs.readFileSync('ios/App/App.xcodeproj/project.pbxproj','utf8').includes('PrivacyInfo.xcprivacy in Resources'));
 assert(fs.readFileSync('android/variables.gradle','utf8').includes('targetSdkVersion = 36'));
 assert(fs.readFileSync('android/app/src/main/AndroidManifest.xml','utf8').includes('ACCESS_FINE_LOCATION'));
 console.log('PASS: native GPS/denied permission, modal stacking, meal draft, persistent files, no session leakage, camera cancellation, map lifetime, Android back, JS syntax and native configuration.');w.close();
})().catch(error=>{console.error(error);process.exit(1)});
