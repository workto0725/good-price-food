# 한끼일기+ 안드로이드·아이폰 프로젝트

현재 웹 디자인을 유지한 앱 개발 프로젝트입니다. 이 ZIP은 설치 파일(APK/IPA)이나 스토어 제출 파일(AAB)이 아닙니다. 현재 웹사이트의 기록이 앱으로 자동 이동하지 않으므로 웹에서 백업 후 앱에서 불러와야 합니다.

## 포함한 기능

- 기기에 포함된 화면: 인터넷이 없어도 개인 기록 작성·열람·검색
- 네이티브 위치 검색, 카메라/사진 선택, 파일 백업과 추천 카드 공유
- 기록을 앱 전용 파일과 복구용 사본에 저장 (앱 삭제 시 제거됨)
- 작성 중 검색 화면을 앞에 표시하고 내용을 유지
- 안드로이드 뒤로가기, 아이폰 화면 안전 영역 처리
- 이메일 회원·관리자 승인·신고 기능 유지, 기기별 사용자 차단과 탈퇴 화면 추가
- 안드로이드 프로젝트, Xcode 프로젝트, 앱 아이콘, 권한 안내, iOS Privacy Manifest

## 컴퓨터에서 준비

Node.js 22 이상, Python 3, Android Studio/Android SDK 또는 Mac의 Xcode가 필요합니다. 아이콘 재생성에만 Python Pillow가 필요합니다. Python은 권한 설정 파일을 갱신하는 데 사용됩니다. Android Gradle용 JDK 21 이상을 사용하세요. npm 의존성을 설치한 후 프로젝트를 여세요.

```sh
npm ci
npm run sync
npm test
node scripts/test-edge.cjs
```

안드로이드: `npm run android` → Android Studio에서 SDK를 설치하고 휴대폰 연결 → Run. 정식 배포는 Build 메뉴의 Generate Signed App Bundle / APK에서 **Android App Bundle**을 선택합니다. 서명 키는 이 프로젝트에 포함하지 않았으며 별도로 만들어 안전하게 보관합니다.

아이폰: **Mac**에서 `npm run ios` → Xcode의 Signing & Capabilities에서 본인의 Apple 개발자 Team을 선택 → 아이폰 실기기 실행. 정식 배포는 Product → Archive → Distribute App → App Store Connect 순서로 진행합니다. 프로젝트의 앱 식별자는 `io.github.workto0725.hankkiplus`이며 최초 스토어 등록 전 최종 확정해야 합니다.

## 지도

네이티브 앱은 기기의 `https://localhost`(Android), `capacitor://localhost`(iOS)에서 실행됩니다. 카카오 지도는 기존에 승인된 HTTPS 도메인의 `native-map.html`에서 실행하고 제한된 메시지로 검색과 지도만 연결합니다. 개인 일기 본문·사진·인증 토큰은 이 연결로 보내지 않습니다. 검색·지도·커뮤니티는 인터넷이 필요합니다.

지도 연결 주소는 `src/map-bridge.js`에 있습니다. 호스팅 주소를 바꾸면 함께 수정해야 합니다. `native-map.html`과 기존 `config.js`가 같은 경로에 있어야 하며 로컬 앱에서 직접 카카오 키의 도메인 검사를 우회하지 않습니다.

## 회원 탈퇴

`supabase/functions/delete-account/index.ts`는 JWT로 본인을 확인하고 **검증된 본인 계정만** 삭제합니다. 클라이언트가 보낸 타인 ID를 사용하지 않습니다. 기존 커뮤니티 설정 SQL의 외래키 cascade에 따라 글·저장·신고가 제거됩니다. 익명화된 관리자 감사 기록은 남을 수 있습니다. 서비스 역할 키는 서버 환경에만 있어야 하며 앱에 넣지 마세요.

출시 전 별도의 테스트 계정으로 탈퇴 흐름과 연결된 데이터 제거를 확인해야 합니다. 운영 중인 관리자 계정으로 테스트하지 마세요. 외부 삭제 페이지 `account-delete.html`도 포함했습니다.

## 아직 필요한 출시 준비

1. 실제 안드로이드·아이폰에서 위치 허용/거부, 사진, 저장·재시작, 지도, 오프라인, 백업/복원을 확인
2. 실제 테스트 계정으로 커뮤니티 가입·글 제출·관리자 승인·신고·사용자 차단·탈퇴 확인
3. 공개 운영자 이름과 문의 이메일을 확정하여 `src/privacy.html`·`src/terms.html` 초안을 마무리하고 공개 URL에 게시
4. Supabase 처리 지역, 로그 보관기간 등 실제 운영 설정을 확인하고 스토어 개인정보/데이터 보안 답변 작성
5. 개발자 계정의 본인 인증·약관·결제, 앱 서명, 실제 기기 화면 이미지 준비
6. Google Play 테스트 및 Apple TestFlight 후 제출

현재 환경에서는 JavaScript 번들 생성·네이티브 프로젝트 생성·시뮬레이션 테스트를 수행했습니다. Android 빌드는 SDK 미설치와 Gradle 다운로드 네트워크 제한으로 완료하지 못했고, iOS는 Mac/Xcode가 없어 컴파일하지 못했습니다. 스토어 심사 승인 여부를 보장하지 않습니다.

## 소스 수정

`src/index.html`의 화면을 수정하고 `npm run sync`를 실행합니다. `scripts/store-features.mjs`는 최초 웹 코드에 앱용 차단·탈퇴 UI를 추가한 도구이며 지금은 적용되어 있습니다. `scripts/icons.py`로 아이콘을 다시 만들 수 있습니다. 테스트는 기기 API를 모의 실행하므로 실기기 테스트를 대체하지 않습니다.

참고: [Capacitor 설정](https://capacitorjs.com/docs/getting-started), [Apple 앱 심사 지침](https://developer.apple.com/kr/app-store/review/guidelines/), [Google Play 등록](https://support.google.com/googleplay/android-developer/answer/6112435).

## 배포 상태

앱용 지도 연결 페이지와 외부 계정 삭제 안내 페이지는 기존 GitHub Pages에 반영했습니다. Supabase `delete-account` 함수도 배포하여 인증 없는 요청의 401 거부를 확인했습니다. 게이트웨이의 레거시 JWT 검사는 끄고 함수 내부 `auth.getUser`로 토큰을 검증합니다. 같은 설정은 `supabase/config.toml`에 포함되어 있습니다. 실제 테스트 계정의 삭제와 휴대폰 동작은 출시 전에 확인해야 합니다.
